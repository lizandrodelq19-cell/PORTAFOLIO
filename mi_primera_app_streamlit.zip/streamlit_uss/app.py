import streamlit as st
from pathlib import Path

# Configuración general de la página
st.set_page_config(
    page_title="Mi primera aplicación de Streamlit",
    page_icon="🎓",
    layout="wide"
)

# Estilos para acercarse al diseño de la tarea
st.markdown("""
<style>
    .main-title {
        font-size: 2rem;
        font-weight: 700;
        color: #343746;
        margin-bottom: 0.2rem;
    }
    .subtitle {
        color: #343746;
        font-size: 1.25rem;
        font-weight: 600;
    }
    div.stButton > button {
        border-radius: 7px;
        border: 1px solid #d7dce3;
    }
</style>
""", unsafe_allow_html=True)

# ---------------- BARRA LATERAL ----------------
with st.sidebar:
    st.title("Mi primera barra lateral de Streamlit")
    st.write("¡Hola, Barra Lateral!")
    st.caption("Esta es una barra lateral")

    logo_path = Path(__file__).parent / "assets" / "logo_uss.png"
    if logo_path.exists():
        st.image(str(logo_path), use_container_width=True)

    if st.button("Haz clic pero en la barra lateral"):
        st.info("¡Hiciste clic en la barra lateral!")

    st.write("Escribe algo en la caja:")
    texto_lateral = st.text_input(
        "Texto de la barra lateral",
        placeholder="Escribe aquí...",
        label_visibility="collapsed",
        key="texto_lateral"
    )
    st.write("Escribiste en la barra:")
    if texto_lateral:
        st.write(texto_lateral)
    else:
        st.caption("Tu texto aparecerá aquí.")

# ---------------- ÁREA PRINCIPAL ----------------
st.markdown(
    '<div class="main-title">Mi primera aplicación de Streamlit</div>',
    unsafe_allow_html=True
)
st.markdown('<div class="subtitle">¡Hola, Streamlit!</div>', unsafe_allow_html=True)
st.write("Esta es una aplicación simple")

if logo_path.exists():
    st.image(str(logo_path), width=300)

if "mensaje" not in st.session_state:
    st.session_state.mensaje = ""

entrada = st.text_input(
    "Escribe algo:",
    placeholder="Escribe tu mensaje aquí...",
    key="entrada_principal"
)

if st.button("Haz clic"):
    if entrada.strip():
        st.session_state.mensaje = entrada.strip()
    else:
        st.warning("Primero escribe un mensaje en la caja.")

st.write("Escribiste:")
if st.session_state.mensaje:
    st.success(st.session_state.mensaje)
else:
    st.info("Aquí aparecerá el mensaje que escribas y envíes.")
