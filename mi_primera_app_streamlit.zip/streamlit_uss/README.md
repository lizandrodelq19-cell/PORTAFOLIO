# Mi primera aplicación de Streamlit

Proyecto de una aplicación sencilla para la tarea evaluativa. Contiene:

- Barra lateral (`st.sidebar`) con texto, imagen, botón y caja de texto.
- Área principal con título, imagen, campo de entrada y botón.
- Presentación del mensaje escrito por el usuario.

## 1. Ejecutar en tu computador

Instala Python y abre una terminal dentro de esta carpeta. Ejecuta:

```bash
pip install -r requirements.txt
streamlit run app.py
```

Se abrirá la aplicación en el navegador, normalmente en `http://localhost:8501`.

## 2. Subir el proyecto a GitHub

1. Entra a https://github.com e inicia sesión.
2. Presiona **New repository**.
3. Escribe como nombre: `mi-primera-app-streamlit`.
4. Selecciona **Public** (si tu profesor necesita ver el repositorio).
5. Presiona **Create repository**.
6. Dentro del repositorio, selecciona **Add file > Upload files**.
7. Sube `app.py`, `requirements.txt`, `README.md` y la carpeta `assets` completa.
8. Presiona **Commit changes**.

## 3. Publicar la aplicación con Streamlit Community Cloud

GitHub guarda el código; para que la aplicación funcione como una página web, publícala en Streamlit Community Cloud:

1. Entra a https://share.streamlit.io/
2. Inicia sesión con GitHub y autoriza el acceso.
3. Presiona **Create app**.
4. Selecciona tu repositorio `mi-primera-app-streamlit`.
5. En **Main file path**, escribe `app.py`.
6. Presiona **Deploy**.

Cuando termine, Streamlit te entregará un enlace para compartir con tu profesor.

## Importante

El logotipo incluido se recortó de la imagen de referencia de la tarea y puede verse algo pixelado. Si tienes el archivo original del logo de la Universidad San Sebastián, reemplaza `assets/logo_uss.png` por ese archivo y conserva el mismo nombre.
